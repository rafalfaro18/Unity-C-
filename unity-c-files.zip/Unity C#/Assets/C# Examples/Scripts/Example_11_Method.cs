﻿using UnityEngine;
using System.Collections;

public class Example_11_Method : MonoBehaviour
{
	void Start ()
	{
		float total = AddValues (10, 3.5f);

		Debug.Log ("Total is: " + total);
	}

	float AddValues ( float a, float b )
	{
		return a + b;
	}
}
