﻿using UnityEngine;
using System.Collections;

public class Example_4_Enum : MonoBehaviour
{
	public enum LevelOfDifficulty { easy, medium, hard, difficult };

	public LevelOfDifficulty levelOfDifficulty = LevelOfDifficulty.easy;

	void Start ()
	{
		Debug.Log ("Starting level of difficulty: " + levelOfDifficulty);
	}
}
