﻿using UnityEngine;
using System.Collections;

public class Example_7_Muti_Conditional : MonoBehaviour
{
	public int lives = 3;
	public bool canAddLives = false;

	void Update ()
	{
		// &&, ||
		if ( lives > 0 && canAddLives == true )
		{
			Debug.Log ( "Player can have extra lives.");
		}

		if ( lives <= 0 || canAddLives == true )
		{
			Debug.Log ( "Player has no lives left, but can add lives.");
		}
	}
}
