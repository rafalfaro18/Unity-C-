﻿using UnityEngine;
using System.Collections;

public class Example_5_Arithmetic : MonoBehaviour
{
	// +, -, *, /

	int ammo = 100;
	int ammoPickup = 10;
	int ammoPickupDouble = 2;
	int ammoPickupReduce = 10;

	void Start ()
	{
		/*
		ammo++;
		ammo--;

		++ammo;
		--ammo;

		ammo += ammoPickup;
		ammo = ammo + ammoPickup;
		ammo -= 20;
		ammo = ammo - 20;

		Debug.Log ( "Ammo count: " + ammo );
		*/

		int total = ammo + ammoPickup;

		total = total / ammoPickupReduce;

		total = (10 + (ammo * ammoPickup)) * 2;

		total = total * ammoPickupDouble;
		// ammo + ammoPickup * double
		// 100 + 10 * 2
		
		Debug.Log ( "Ammo: " + total );
	}
}
