﻿using UnityEngine;
//using System.Collections;

public class Example_1 : MonoBehaviour
{
	public string message = "Hello World";

	void Start ()
	{
		Debug.Log (message);
	}
}