﻿using UnityEngine;
using System.Collections;

public class Example_2_Variables : MonoBehaviour
{
	public string playerName = "Player Name";
	[Range (0,100)] public int playerHealth = 100;
	public float playerSpeed = 5.0f;
	[HideInInspector] public bool isGameOver = false;
	
	void Start ()
	{
		Debug.Log ( playerName + " " +  playerHealth + " " + playerSpeed + " " + isGameOver );
	}
}
