﻿using UnityEngine;
using System.Collections;

public class Example_9_Loop : MonoBehaviour
{
	public int counterMax = 10;

	void Start ()
	{
		for ( int i = 0; i < counterMax; i++ )
		{
			Debug.Log ( "i: " + i );

			for ( int j = 0; j < 2; j++ )
			{
				Debug.Log ( "J: " + j );
			}
		}



		/*
		int i = 0;

		while ( i < counterMax ) 
		{
			Debug.Log ( "Counting: " + i );

			i++;
		}


		Debug.Log ("Start");

		for ( int i = 0; i <= counterMax; i++ )
		{
			Debug.Log ( "Counting: " + i );
		}

		Debug.Log ("Finished");
		*/
	}
}
