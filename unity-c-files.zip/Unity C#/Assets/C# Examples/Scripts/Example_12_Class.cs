﻿using UnityEngine;
using System.Collections;

public class Example_12_Class : MonoBehaviour
{
	// class - does a particular set of instructions
	// variables (type) - using these
	// methods - self contained and benefit the class
}
