﻿using UnityEngine;
using System.Collections;

public class Example_10_Foreach : MonoBehaviour
{
	string[] friends = new string[]{ "john", "sue", "brad" };

	void Start ()
	{
		foreach ( string friend in friends )
		{
			Debug.Log ( "Names of friends: " + friend );
		}
	}
}
