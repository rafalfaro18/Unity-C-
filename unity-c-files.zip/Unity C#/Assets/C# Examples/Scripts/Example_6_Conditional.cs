﻿using UnityEngine;
using System.Collections;

public class Example_6_Conditional : MonoBehaviour
{
	public int health = 100;
	public bool gameOver = false;
	public bool hasWon = false;
	public bool hasLost = false;

	void Update ()
	{
		// > < >= <= == 
		if ( health > 80 )
		{
			Debug.Log ( "Healthy" );
		}
		else if ( health > 20 )
		{
			Debug.Log ( "Healthy, but weak" );
		}
		else if ( health > 0 )
		{
			Debug.Log ( "Not healthy" );
		}
		else 
		{
			Debug.Log ("See a doctor");
		}

		if ( gameOver == false )
		{
			if ( hasWon == true )
			{
				Debug.Log ( "Player has won!" );
			}
			else if ( hasLost == true )
			{
				Debug.Log ( "Player has lost." );
			}
			else
			{
				// Default if neither correct
			}
		}
	}
}
